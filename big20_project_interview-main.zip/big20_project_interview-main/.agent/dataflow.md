[사용자 음성] 
    ↓ (WebRTC Audio Track)
[Media Server - Deepgram STT]
    ↓ (실시간 전사)
[WebSocket 전송]
    ↓
[Frontend - transcript 상태 업데이트]
    ↓
[화면에 실시간 표시]
    ↓ (다음 질문 클릭)
[Backend - DB 저장]